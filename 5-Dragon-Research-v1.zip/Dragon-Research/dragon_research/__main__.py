"""Run: python -m dragon_research --help"""
import argparse
import json
import sys
from pathlib import Path
from datetime import datetime, timezone
from .core import Client, address, best_pair, screen, token_risk, wallet_history, ledger_event

def main():
    p=argparse.ArgumentParser(description='Dragon Research: free, keyless, read-only. No profit guarantee.')
    p.add_argument('--cache',default='.dragon-cache')
    sub=p.add_subparsers(dest='cmd',required=True)
    for name in ('token','risk','monitor'):
        s=sub.add_parser(name);s.add_argument('mint')
        if name=='monitor':
            s.add_argument('--entry',type=float,required=True);s.add_argument('--stop',type=float,default=0.65);s.add_argument('--tp',type=float,default=1.6)
    sub.add_parser('candidates')
    s=sub.add_parser('wallet');s.add_argument('wallet');s.add_argument('--limit',type=int,default=5)
    s=sub.add_parser('watchlist');s.add_argument('file');s.add_argument('--limit',type=int,default=3)
    s=sub.add_parser('paper');s.add_argument('file');s.add_argument('side',choices=['buy','sell']);s.add_argument('mint');s.add_argument('quantity');s.add_argument('price_usd');s.add_argument('--fee-usd',default='0')
    a=p.parse_args();c=Client(cache=a.cache)
    if a.cmd=='paper':
        f=Path(a.file);events=json.loads(f.read_text()) if f.exists() else []
        e={'side':a.side,'mint':address(a.mint),'quantity':a.quantity,'price_usd':a.price_usd,'fee_usd':a.fee_usd,'timestamp':datetime.now(timezone.utc).isoformat()}
        out=ledger_event(events,e);f.write_text(json.dumps(events+[e],indent=2))
    elif a.cmd=='wallet':out=wallet_history(c,a.wallet,a.limit)
    elif a.cmd=='watchlist':
        wallets=[address(v.strip()) for v in Path(a.file).read_text().splitlines() if v.strip() and not v.lstrip().startswith('#')]
        if len(wallets)>5:raise ValueError('Maximum 5 wallets per invocation')
        out=[wallet_history(c,w,a.limit) for w in wallets]
    elif a.cmd=='risk':out=token_risk(c,a.mint)
    elif a.cmd=='candidates':
        seen=set();out=[]
        for route in ('/token-boosts/top/v1','/token-profiles/latest/v1'):
            for row in c.request('https://api.dexscreener.com'+route):
                if row.get('chainId')!='solana':continue
                mint=address(row['tokenAddress'])
                if mint in seen:continue
                if len(seen)>=20:break
                seen.add(mint)
                pair=best_pair(c.token(mint),mint);out.append(screen(pair))
        out={'sample':out,'warning':'Paid boosts/profile submissions are biased discovery, not organic trending or alpha. No safety clearance.'}
    else:
        pair=best_pair(c.token(address(a.mint)),a.mint);out=screen(pair)
        out['price_usd']=pair.get('priceUsd')
        if a.cmd=='monitor':
            if a.entry<=0 or not 0<a.stop<1 or a.tp<=1:raise ValueError('Invalid entry/stop/TP')
            px=float(pair['priceUsd']);out['reference_return_pct']=(px/a.entry-1)*100
            out['stop_trigger_usd']=a.entry*a.stop;out['tp_trigger_usd']=a.entry*a.tp
            out['alert']='BELOW STOP REFERENCE' if px<=a.entry*a.stop else 'ABOVE TP REFERENCE' if px>=a.entry*a.tp else 'between references'
            out['execution']='NONE: does not submit orders or verify existing orders; price is a pool reference, not executable quote'
    print(json.dumps({'as_of_utc':datetime.now(timezone.utc).isoformat(),'result':out},indent=2))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('Research failed, no action taken: '+str(e),file=sys.stderr);sys.exit(1)
