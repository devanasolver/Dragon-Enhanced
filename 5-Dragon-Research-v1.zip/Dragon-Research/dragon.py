"""Read-only launcher. Never imports the old GMGN scraper."""
import sys
from pathlib import Path
if not (Path(__file__).parent/'dragon_research').is_dir():
    archive=Path(__file__).parent/'dragon-research-source.zip'
    if not archive.is_file():raise SystemExit('Missing dragon_research package or dragon-research-source.zip')
    sys.path.insert(0,str(archive))
from dragon_research.__main__ import main
if __name__=='__main__':
    main()
