import unittest
from dragon_research.core import *
M='So11111111111111111111111111111111111111112'
class CoreTests(unittest.TestCase):
    def test_address(self):
        self.assertEqual(address(M),M)
        for bad in ('secret','https://bad.test','0'*44):
            with self.assertRaises(ValueError):address(bad)
    def test_missing_not_pass(self):self.assertFalse(screen({})['momentum_pass'])
    def test_good_momentum_not_safety(self):
        d={'pairCreatedAt':3600000,'liquidity':{'usd':20000},'marketCap':100000,'priceChange':{'h1':10,'m5':1},'txns':{'h1':{'buys':60,'sells':40}}}
        r=screen(d,7200);self.assertTrue(r['momentum_pass']);self.assertIn('NOT CLEARED',r['safety_status'])
    def test_wrong_pair(self):
        with self.assertRaises(ValueError):best_pair({'pairs':[{'chainId':'eth'}]},M)
    def test_paper_fees(self):
        b={'side':'buy','mint':M,'quantity':'10','price_usd':'1','fee_usd':'.1'}
        s={'side':'sell','mint':M,'quantity':'5','price_usd':'2','fee_usd':'.1'}
        r=ledger_event([b],s);self.assertEqual(r['realized_usd'],'4.85')
    def test_oversell(self):
        with self.assertRaises(ValueError):ledger_event([],{'side':'sell','mint':M,'quantity':'1','price_usd':'1'})
    def test_transfer_not_profit(self):
        tx={'meta':{'err':None,'preBalances':[1000000000],'postBalances':[2000000000]},'transaction':{'message':{'accountKeys':[M]}}}
        r=transaction_evidence(tx,M,'sample');self.assertEqual(r['sol_balance_delta_including_fees_and_rent'],1);self.assertIn('UNKNOWN',r['realized_pnl'])
    def test_failed_tx(self):self.assertIn('excluded',transaction_evidence({'meta':{'err':{'x':1}}},M,'s')['coverage'])
    def test_missing_tx(self):self.assertIn('unavailable',transaction_evidence(None,M,'s')['coverage'])
    def test_no_rpc_send(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):Client(d).rpc('sendTransaction',[])
if __name__=='__main__':unittest.main()

class RiskTests(unittest.TestCase):
    def test_risk_never_safe(self):
        class Fake:
            def rpc(self,method,params):
                if method=='getAccountInfo':return {'value':{'owner':TOKEN_PROGRAM,'data':{'parsed':{'type':'mint','info':{'supply':'100','mintAuthority':None,'freezeAuthority':None}}}}}
                return {'value':[{'amount':'20'}]}
        r=token_risk(Fake(),M);self.assertEqual(r['top10_token_account_pct'],20);self.assertIn('UNKNOWN',r['lp_lock']);self.assertIn('REVIEW',r['verdict'])
    def test_unknown_mint(self):
        class Fake:
            def rpc(self,*args):return {'value':None}
        with self.assertRaises(ValueError):token_risk(Fake(),M)
