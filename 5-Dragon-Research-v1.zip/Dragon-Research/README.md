# Dragon Research: keyless Solana strategy companion

A read-only research branch of Dragon-Enhanced, inspired by Dragon's wallet-analysis workflow. Built for a cautious Jupiter memecoin workflow, not a trading bot. No profit promise. Nothing here places orders, signs transactions or needs private keys.

## Quick start

Python 3.11+, no third-party runtime dependencies. There is nothing to install with pip.

```sh
python dragon.py --help
unzip dragon-research-source.zip
python -m unittest discover -s tests -v
python dragon.py token PUBLIC_MINT
python dragon.py risk PUBLIC_MINT
python dragon.py wallet PUBLIC_WALLET --limit 3
python dragon.py watchlist watchlist.txt --limit 3
python dragon.py candidates
python dragon.py monitor PUBLIC_MINT --entry 0.01 --stop 0.65 --tp 1.6
python dragon.py paper paper-ledger.json buy PUBLIC_MINT 100 0.01 --fee-usd 0.02
python dragon.py paper paper-ledger.json sell PUBLIC_MINT 50 0.015 --fee-usd 0.02
```

Use real public addresses instead of the placeholders. Keep wallet watchlists and paper ledgers local. Never paste a seed phrase or secret key into any command. `dragon.py` is the compatibility entry point. A packaged source zip can also be used by that launcher when installed from the browser-upload branch.

## Tools and boundaries

- **Candidate screener:** maximum 20 deduplicated Solana tokens from DexScreener boosted/profile submissions. These are biased sources, NOT an organic trending index. Default research filters: liquidity >=$15k, cap $50k-$10m, age 30m-24h, 1h change >=5%, 5m change >=-6%, buy-count ratio >=50%. Passing momentum never clears safety.
- **Token risk:** direct SPL mint/freeze authority evidence, extensions, top-10 token-account concentration. Token accounts are not beneficial owners; pools/custody can inflate concentration. LP lock/burn, bundles, honeypot status remain UNKNOWN. No blanket PumpSwap exemption.
- **Wallet evidence/watchlist:** 1-20 recent signatures per wallet, at most five supplied wallets per watchlist invocation. Reports native SOL and owned-token balance changes, failed/missing transaction coverage. Balance changes include rent/fees/transfers and are NOT automatically buy/sell classifications. Realized wallet profit is UNKNOWN without decoded swaps and matched cost basis. This version does not discover or rank profitable wallets.
- **Paper ledger:** local manual-price buy/sell events, weighted-average cost, partial exits, explicit simulated fees and oversell protection. Not live execution results. No backtest or predictive validation is claimed.
- **Position reference monitor:** one-shot token price against entry/stop/TP references. No recurring job, order placement, executable quote, guarantee, or existing Jupiter-order verification. It does not replace exchange-side protection.

## Data, limits and failure handling

Only public DexScreener and Solana mainnet RPC are used. JSON responses are cached for 60 seconds; the as-of timestamp is report-generation time and a cached observation can be up to 60 seconds older. Requests are paced, have 20-second timeouts and stop on HTTP/RPC errors. A 429 or 403 records a shared minimum 60-second cooldown, honoring a longer numeric Retry-After. There is no retry storm, proxy rotation, CAPTCHA bypass, login or paid endpoint.

Free public RPC is rate-limited and not reliable production indexing. Large historical scans, all-chain early buyers, full 30-day P&L and authoritative bundle detection are out of scope. Errors are failures, not clean safety verdicts or empty histories. Default outputs are JSON for inspection or offline comparison.

## Validation status (October 18, 2026)

- Offline unit tests cover address filtering, missing evidence, pool identity, screening, fee-aware paper arithmetic, oversells, failed/missing transactions, transfer-not-profit semantics, and refusing transaction-submission RPC methods.
- Live smoke tests: token market read, one recent wallet transaction, reference-price monitor worked without API keys.
- Live token-risk smoke test hit public RPC HTTP 429 and stopped. The path is fixture-tested; live completion is not established.
- No dependency installation or third-party scraper execution was used.
- No historical backtest, forward paper sample, or profit validation yet. Do not let this tool influence live entries until its observations are checked against independent records and a forward paper sample.

## Removed from the active tool

The mutable self-updater, GMGN scraping, TLS impersonation, Cloudflare/proxy components, signing and auto-trading are absent from this implementation and are never imported by the new launcher. The active tool runtime requirements are empty, so there are no unpinned runtime packages. Original upstream code may remain as inactive legacy files on the publication branch; the new launcher does not import it. It also remains recoverable in Git history; preserve applicable upstream attribution/license terms before redistributing. This is not a security certification.

## Sources

- Original Dragon: https://github.com/1f1n/Dragon
- Existing fork: https://github.com/devanasolver/Dragon-Enhanced
- Public RPC limitations: https://solana.com/docs/references/clusters
- Signatures: https://solana.com/docs/rpc/http/getsignaturesforaddress
- Transactions: https://solana.com/docs/rpc/http/gettransaction
- Market API: https://docs.dexscreener.com/api/reference
